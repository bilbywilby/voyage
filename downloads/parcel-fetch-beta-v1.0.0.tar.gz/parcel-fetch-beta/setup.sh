#!/bin/bash

# Parcel Fetch Beta - Setup Script
# This script helps you get started quickly

set -e

echo "🗺️  Parcel Finder Beta - Setup Script"
echo "======================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 14+ first."
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 14 ]; then
    echo "❌ Node.js version must be 14 or higher. Current version: $(node -v)"
    exit 1
fi

echo "✅ Node.js $(node -v) detected"
echo ""

# Install server dependencies
echo "📦 Installing server dependencies..."
cd server
if [ ! -f ".env" ]; then
    echo "Creating .env file from example..."
    cp .env.example .env
fi
npm install
cd ..

echo "✅ Server dependencies installed"
echo ""

# Install client dependencies
echo "📦 Installing client dependencies..."
cd client
npm install
cd ..

echo "✅ Client dependencies installed"
echo ""

# Create necessary directories
echo "📁 Creating necessary directories..."
mkdir -p server/logs
mkdir -p server/output

echo "✅ Directories created"
echo ""

echo "✨ Setup complete!"
echo ""
echo "🚀 To start the application:"
echo ""
echo "  Terminal 1 (Backend):"
echo "    cd server"
echo "    npm run dev"
echo ""
echo "  Terminal 2 (Frontend):"
echo "    cd client"
echo "    npm run dev"
echo ""
echo "  Then open: http://localhost:3000"
echo ""
echo "📖 For more information, see README.md"
echo ""
echo "🐳 Alternatively, use Docker:"
echo "    docker-compose up"
echo ""
