const https = require('https');
const GeocodingUtility = require('./geocoding');

class ParcelFetcher {
  constructor(config, logger) {
    this.config = config;
    this.logger = logger;
  }

  /**
   * Fetch parcel data using an address (geocode first, then query)
   * @param {string} address - Address to look up
   * @param {string} language - Geocoding language (default: 'en')
   * @returns {Promise<Object>} Parcel data
   */
  async fetchParcelWithGeocoding(address, language = 'en') {
    const performanceTracker = this.logger.createPerformanceTracker('Geocoding + Parcel Fetch');

    try {
      this.logger.log('info', `Fetching parcel for address: ${address}`, { address });

      // Step 1: Geocode the address
      const location = await GeocodingUtility.encode(address, language);
      this.logger.log('info', 'Geocoding successful', {
        latitude: location.latitude,
        longitude: location.longitude,
        formatted_address: location.formatted_address
      });

      // Step 2: Fetch parcel using coordinates
      const parcelData = await this.fetchParcelByCoordinates(
        location.latitude,
        location.longitude
      );

      performanceTracker.end();

      // Enrich with geocoding info
      if (parcelData) {
        parcelData.geocoding = {
          input_address: address,
          formatted_address: location.formatted_address,
          place_id: location.place_id
        };
      }

      return parcelData;

    } catch (error) {
      this.logger.trackError(error, {
        address,
        method: 'fetchParcelWithGeocoding'
      });
      throw error;
    }
  }

  /**
   * Fetch parcel data by coordinates
   * @param {number} latitude - Latitude
   * @param {number} longitude - Longitude
   * @param {Object} options - Query options
   * @returns {Promise<Object>} Parcel data
   */
  async fetchParcelByCoordinates(latitude, longitude, options = {}) {
    // Validate coordinates
    if (!GeocodingUtility.validateCoordinates(latitude, longitude)) {
      throw new Error(`Invalid coordinates: ${latitude}, ${longitude}`);
    }

    const defaultOptions = {
      spatialRelationship: 'esriSpatialRelContains',
      returnGeometry: true,
      outSpatialReference: { wkid: 4326 },
      geometryType: 'esriGeometryPoint',
      maxAllowedOffset: 0.00001,
      fields: this.config.DEFAULT_FIELDS || ['*']
    };

    const queryOptions = { ...defaultOptions, ...options };

    const spatialQuery = {
      geometryType: queryOptions.geometryType,
      geometry: JSON.stringify({
        x: longitude,
        y: latitude,
        spatialReference: { wkid: 4326 }
      }),
      spatialRel: queryOptions.spatialRelationship,
      outFields: Array.isArray(queryOptions.fields) ? queryOptions.fields.join(',') : '*',
      returnGeometry: queryOptions.returnGeometry,
      f: 'json'
    };

    try {
      const response = await this.performSpatialRequest(spatialQuery);

      if (!response.features || response.features.length === 0) {
        this.logger.log('warn', `No parcel found at coordinates (${latitude}, ${longitude})`);
        
        // Try fallback with buffer
        return await this.fallbackParcelLookup(latitude, longitude);
      }

      if (response.features.length > 1) {
        this.logger.log('warn', `Multiple parcels found at coordinates. Using first match.`, {
          count: response.features.length
        });
      }

      const parcel = response.features[0];
      return this.enrichParcelData(parcel, { latitude, longitude });

    } catch (error) {
      this.logger.log('error', 'Spatial query failed', { error: error.message });
      throw error;
    }
  }

  /**
   * Perform spatial request to ArcGIS server
   * @param {Object} queryParams - Query parameters
   * @returns {Promise<Object>} Response data
   */
  async performSpatialRequest(queryParams) {
    return new Promise((resolve, reject) => {
      const params = new URLSearchParams(queryParams);
      
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json'
        }
      };

      const req = https.request(
        `${this.config.LAYER_URL}/query`,
        options,
        (res) => {
          let data = '';
          
          res.on('data', chunk => {
            data += chunk;
          });
          
          res.on('end', () => {
            try {
              const parsedData = JSON.parse(data);
              
              if (parsedData.error) {
                reject(new Error(`ArcGIS Error: ${parsedData.error.message}`));
              } else {
                resolve(parsedData);
              }
            } catch (parseError) {
              reject(new Error(`Response parsing failed: ${parseError.message}`));
            }
          });
        }
      );

      req.on('error', (error) => {
        reject(new Error(`Request failed: ${error.message}`));
      });

      req.write(params.toString());
      req.end();
    });
  }

  /**
   * Enrich parcel data with additional calculated fields
   * @param {Object} parcel - Raw parcel data from ArcGIS
   * @param {Object} locationInfo - Location information
   * @returns {Object} Enriched parcel data
   */
  enrichParcelData(parcel, locationInfo) {
    const attributes = parcel.attributes || {};

    return {
      ...attributes,
      geometry: parcel.geometry,
      location: {
        latitude: locationInfo.latitude,
        longitude: locationInfo.longitude,
        precision: 'high'
      },
      metadata: {
        queryTimestamp: new Date().toISOString(),
        source: 'Lehigh County Parcel Viewer',
        coordinateSystem: 'WGS84',
        layerUrl: this.config.LAYER_URL
      },
      derivedProperties: {
        assessedValuePerAcre: this.calculateValuePerAcre(attributes),
        propertyAge: this.calculatePropertyAge(attributes),
        hasMultipleOwners: this.checkMultipleOwners(attributes)
      }
    };
  }

  /**
   * Fallback parcel lookup using buffer search
   * @param {number} latitude - Latitude
   * @param {number} longitude - Longitude
   * @param {number} maxRadius - Search radius in degrees (default: 0.001)
   * @returns {Promise<Object>} Parcel data or null
   */
  async fallbackParcelLookup(latitude, longitude, maxRadius = 0.001) {
    this.logger.log('info', 'Attempting fallback parcel lookup with buffer', {
      latitude,
      longitude,
      radius: maxRadius
    });

    const bufferQuery = {
      geometryType: 'esriGeometryPoint',
      geometry: JSON.stringify({
        x: longitude,
        y: latitude,
        spatialReference: { wkid: 4326 }
      }),
      spatialRel: 'esriSpatialRelIntersects',
      distance: maxRadius,
      units: 'esriSRUnit_Degree',
      outFields: '*',
      returnGeometry: true,
      f: 'json'
    };

    try {
      const response = await this.performSpatialRequest(bufferQuery);

      if (response.features && response.features.length > 0) {
        this.logger.log('warn', `Fallback: Found ${response.features.length} parcels within buffer`);
        return this.enrichParcelData(response.features[0], { latitude, longitude });
      }

      this.logger.log('error', 'No parcels found in fallback search');
      return null;

    } catch (error) {
      this.logger.log('error', 'Fallback lookup failed', { error: error.message });
      return null;
    }
  }

  /**
   * Calculate assessed value per acre
   * @param {Object} attributes - Parcel attributes
   * @returns {number} Value per acre
   */
  calculateValuePerAcre(attributes) {
    const value = parseFloat(attributes.ASSESSED_VAL) || 0;
    const acres = parseFloat(attributes.ACRES) || 1;
    return acres > 0 ? value / acres : 0;
  }

  /**
   * Calculate property age based on tax year
   * @param {Object} attributes - Parcel attributes
   * @returns {number} Property age in years
   */
  calculatePropertyAge(attributes) {
    const currentYear = new Date().getFullYear();
    const taxYear = parseInt(attributes.TAX_YEAR) || currentYear;
    return currentYear - taxYear;
  }

  /**
   * Check if parcel has multiple owners
   * @param {Object} attributes - Parcel attributes
   * @returns {boolean} True if multiple owners detected
   */
  checkMultipleOwners(attributes) {
    const ownerName = attributes.OWNER_NAME || '';
    return ownerName.includes('&') || 
           ownerName.includes(' AND ') || 
           ownerName.includes(',');
  }
}

module.exports = ParcelFetcher;
