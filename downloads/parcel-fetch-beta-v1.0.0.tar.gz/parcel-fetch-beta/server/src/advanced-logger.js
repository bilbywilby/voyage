const fs = require('fs');
const path = require('path');
const os = require('os');

class AdvancedLogger {
  constructor(config = {}) {
    this.config = {
      logDir: config.LOG_DIR || path.join(process.cwd(), 'logs'),
      logLevel: process.env.LOG_LEVEL || config.LOG_LEVEL || 'info',
      performanceThresholds: config.PERFORMANCE_THRESHOLDS || {
        slowQueryMs: 500,
        criticalQueryMs: 2000
      },
      errorReporting: config.ERROR_REPORTING || {
        captureStackTrace: true,
        sensitiveDataMask: ['password', 'token', 'key', 'secret']
      },
      ...config
    };

    this.logLevels = {
      error: 0,
      warn: 1,
      info: 2,
      debug: 3
    };

    this.ensureLogDirectory();
  }

  ensureLogDirectory() {
    if (!fs.existsSync(this.config.logDir)) {
      fs.mkdirSync(this.config.logDir, { recursive: true });
    }
  }

  log(level, message, metadata = {}) {
    const currentLevel = this.logLevels[this.config.logLevel] || 2;
    const messageLevel = this.logLevels[level] || 2;

    if (messageLevel > currentLevel) {
      return;
    }

    const timestamp = new Date().toISOString();
    const sanitizedMetadata = this.sanitizeMetadata(metadata);
    
    const logEntry = {
      timestamp,
      level: level.toUpperCase(),
      message,
      ...sanitizedMetadata
    };

    // Console output
    const consoleMessage = `${timestamp} [${level.toUpperCase()}]: ${message}`;
    if (Object.keys(sanitizedMetadata).length > 0) {
      console.log(consoleMessage, sanitizedMetadata);
    } else {
      console.log(consoleMessage);
    }

    // File output
    this.writeToFile(logEntry, level);
  }

  writeToFile(logEntry, level) {
    try {
      const logFile = level === 'error' 
        ? path.join(this.config.logDir, 'error.log')
        : path.join(this.config.logDir, 'combined.log');

      const logLine = JSON.stringify(logEntry) + '\n';
      fs.appendFileSync(logFile, logLine);
    } catch (error) {
      console.error('Failed to write to log file:', error.message);
    }
  }

  createPerformanceTracker(operationName) {
    const startTime = process.hrtime.bigint();

    return {
      end: () => {
        const endTime = process.hrtime.bigint();
        const durationNs = endTime - startTime;
        const durationMs = Number(durationNs) / 1_000_000;

        const level = durationMs > this.config.performanceThresholds.criticalQueryMs
          ? 'error'
          : (durationMs > this.config.performanceThresholds.slowQueryMs ? 'warn' : 'info');

        this.log(level, `Performance: ${operationName}`, {
          duration: durationMs.toFixed(2),
          durationUnit: 'milliseconds'
        });

        return durationMs;
      }
    };
  }

  trackError(error, context = {}) {
    const sanitizedContext = this.sanitizeMetadata(context);

    this.log('error', error.message, {
      name: error.name,
      stack: this.config.errorReporting.captureStackTrace ? error.stack : undefined,
      context: sanitizedContext
    });
  }

  sanitizeMetadata(metadata) {
    const sanitized = { ...metadata };

    this.config.errorReporting.sensitiveDataMask.forEach(key => {
      if (sanitized[key]) {
        sanitized[key] = '***MASKED***';
      }
    });

    return sanitized;
  }

  runDiagnostics() {
    const diagnostics = {
      systemInfo: {
        platform: os.platform(),
        arch: os.arch(),
        cpus: os.cpus().length,
        totalMemory: (os.totalmem() / 1024 / 1024 / 1024).toFixed(2) + ' GB',
        freeMemory: (os.freemem() / 1024 / 1024 / 1024).toFixed(2) + ' GB',
        nodeVersion: process.version
      },
      loggerConfig: {
        logLevel: this.config.logLevel,
        logDir: this.config.logDir
      },
      logDirectory: {
        exists: fs.existsSync(this.config.logDir),
        files: fs.existsSync(this.config.logDir) 
          ? fs.readdirSync(this.config.logDir).length 
          : 0
      }
    };

    this.log('info', 'System Diagnostics', diagnostics);
    return diagnostics;
  }
}

module.exports = AdvancedLogger;
