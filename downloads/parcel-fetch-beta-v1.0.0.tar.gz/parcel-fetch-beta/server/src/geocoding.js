const geocoding = require('@aashari/nodejs-geocoding');

class GeocodingUtility {
  /**
   * Encode an address into coordinates
   * @param {string} address - The address to geocode
   * @param {string} language - Language code (default: 'en')
   * @returns {Promise<Object>} Location object with latitude, longitude, and formatted_address
   */
  static async encode(address, language = 'en') {
    try {
      const locations = await geocoding.encode(address, language);
      
      if (!locations || locations.length === 0) {
        throw new Error(`No geocoding results for address: ${address}`);
      }

      const location = locations[0];
      
      return {
        latitude: location.latitude,
        longitude: location.longitude,
        formatted_address: location.formatted_address,
        place_id: location.place_id,
        types: location.types,
        address_components: location.address_components
      };
    } catch (error) {
      throw new Error(`Geocoding failed for address "${address}": ${error.message}`);
    }
  }

  /**
   * Reverse geocode coordinates into an address
   * @param {number} latitude - Latitude
   * @param {number} longitude - Longitude
   * @param {string} language - Language code (default: 'en')
   * @returns {Promise<Object>} Address object
   */
  static async decode(latitude, longitude, language = 'en') {
    try {
      const results = await geocoding.decode(latitude, longitude, language);
      
      if (!results || results.length === 0) {
        throw new Error(`No reverse geocoding results for coordinates: ${latitude}, ${longitude}`);
      }

      return results[0];
    } catch (error) {
      throw new Error(`Reverse geocoding failed: ${error.message}`);
    }
  }

  /**
   * Validate if coordinates are within valid ranges
   * @param {number} latitude - Latitude to validate
   * @param {number} longitude - Longitude to validate
   * @returns {boolean} True if valid
   */
  static validateCoordinates(latitude, longitude) {
    const lat = parseFloat(latitude);
    const lng = parseFloat(longitude);

    if (isNaN(lat) || isNaN(lng)) {
      return false;
    }

    return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
  }
}

module.exports = GeocodingUtility;
