const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');
const AdvancedLogger = require('./src/advanced-logger');
const ParcelFetcher = require('./src/parcel-fetcher');
const { body, validationResult, query } = require('express-validator');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

// Load configuration
const configPath = path.resolve(__dirname, 'config/parcel-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

// Initialize logger and fetcher
const logger = new AdvancedLogger(config);
const parcelFetcher = new ParcelFetcher(config, logger);

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// Request logging middleware
app.use((req, res, next) => {
  logger.log('info', `${req.method} ${req.path}`, {
    ip: req.ip,
    userAgent: req.get('user-agent')
  });
  next();
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  const diagnostics = logger.runDiagnostics();
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    version: '1.0.0-beta',
    diagnostics
  });
});

// Single address lookup endpoint
app.post('/api/parcel/lookup',
  body('address').notEmpty().trim().isLength({ min: 5, max: 200 }),
  body('language').optional().isIn(['en', 'es', 'fr', 'de']),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { address, language = 'en' } = req.body;
    const performanceTracker = logger.createPerformanceTracker(`Lookup: ${address}`);

    try {
      const parcelData = await parcelFetcher.fetchParcelWithGeocoding(address, language);
      
      if (!parcelData) {
        performanceTracker.end();
        return res.status(404).json({
          error: 'Parcel not found',
          message: `No parcel data found for address: ${address}`
        });
      }

      const duration = performanceTracker.end();
      
      res.json({
        success: true,
        data: parcelData,
        metadata: {
          queryDuration: duration,
          timestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      performanceTracker.end();
      logger.trackError(error, { address, endpoint: '/api/parcel/lookup' });
      
      res.status(500).json({
        error: 'Lookup failed',
        message: error.message
      });
    }
  }
);

// Batch address lookup endpoint
app.post('/api/parcel/batch',
  body('addresses').isArray({ min: 1, max: 50 }),
  body('addresses.*').notEmpty().trim(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { addresses } = req.body;
    const performanceTracker = logger.createPerformanceTracker(`Batch lookup: ${addresses.length} addresses`);

    try {
      const results = await Promise.allSettled(
        addresses.map(address => parcelFetcher.fetchParcelWithGeocoding(address))
      );

      const processed = results.map((result, index) => ({
        address: addresses[index],
        status: result.status,
        data: result.status === 'fulfilled' ? result.value : null,
        error: result.status === 'rejected' ? result.reason.message : null
      }));

      const duration = performanceTracker.end();

      res.json({
        success: true,
        results: processed,
        summary: {
          total: addresses.length,
          succeeded: results.filter(r => r.status === 'fulfilled' && r.value).length,
          failed: results.filter(r => r.status === 'rejected' || !r.value).length,
          duration
        }
      });
    } catch (error) {
      performanceTracker.end();
      logger.trackError(error, { addresses, endpoint: '/api/parcel/batch' });
      
      res.status(500).json({
        error: 'Batch lookup failed',
        message: error.message
      });
    }
  }
);

// Coordinate-based lookup endpoint
app.get('/api/parcel/coordinates',
  query('lat').isFloat({ min: -90, max: 90 }),
  query('lng').isFloat({ min: -180, max: 180 }),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { lat, lng } = req.query;
    const performanceTracker = logger.createPerformanceTracker(`Coordinate lookup: ${lat}, ${lng}`);

    try {
      const parcelData = await parcelFetcher.fetchParcelByCoordinates(
        parseFloat(lat),
        parseFloat(lng)
      );

      if (!parcelData) {
        performanceTracker.end();
        return res.status(404).json({
          error: 'Parcel not found',
          message: `No parcel found at coordinates: ${lat}, ${lng}`
        });
      }

      const duration = performanceTracker.end();

      res.json({
        success: true,
        data: parcelData,
        metadata: {
          queryDuration: duration,
          timestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      performanceTracker.end();
      logger.trackError(error, { lat, lng, endpoint: '/api/parcel/coordinates' });
      
      res.status(500).json({
        error: 'Coordinate lookup failed',
        message: error.message
      });
    }
  }
);

// Get system statistics
app.get('/api/stats', (req, res) => {
  const diagnostics = logger.runDiagnostics();
  
  res.json({
    system: diagnostics.systemInfo,
    logger: {
      logLevel: config.LOG_LEVEL || 'info',
      remoteLogging: config.REMOTE_LOGGING?.ENABLED || false
    },
    service: {
      uptime: process.uptime(),
      memoryUsage: process.memoryUsage(),
      version: '1.0.0-beta'
    }
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  logger.trackError(err, { path: req.path, method: req.method });
  
  res.status(err.status || 500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not found',
    message: `Route ${req.method} ${req.path} not found`
  });
});

// Start server
app.listen(PORT, () => {
  logger.log('info', `Parcel Fetch API Server running on port ${PORT}`, {
    environment: process.env.NODE_ENV || 'development',
    port: PORT
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.log('info', 'SIGTERM signal received: closing HTTP server');
  process.exit(0);
});

module.exports = app;
