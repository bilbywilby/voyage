import React, { useState, useCallback } from 'react';
import { 
  MapPin, 
  Search, 
  Download, 
  Map as MapIcon, 
  List, 
  AlertCircle, 
  CheckCircle, 
  Loader, 
  TrendingUp,
  Home,
  DollarSign,
  Maximize2
} from 'lucide-react';
import './App.css';

function App() {
  const [address, setAddress] = useState('');
  const [coordinates, setCoordinates] = useState({ lat: '', lng: '' });
  const [searchMode, setSearchMode] = useState('address'); // 'address' or 'coordinates'
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [batchAddresses, setBatchAddresses] = useState('');
  const [batchResults, setBatchResults] = useState(null);
  const [showBatchMode, setShowBatchMode] = useState(false);
  const [viewMode, setViewMode] = useState('details'); // 'details' or 'map'

  const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';

  // Single address lookup
  const handleSearch = async () => {
    if (searchMode === 'address' && !address.trim()) {
      setError('Please enter an address');
      return;
    }
    if (searchMode === 'coordinates' && (!coordinates.lat || !coordinates.lng)) {
      setError('Please enter valid coordinates');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      let response;
      
      if (searchMode === 'address') {
        response = await fetch(`${API_BASE}/parcel/lookup`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ address })
        });
      } else {
        response = await fetch(
          `${API_BASE}/parcel/coordinates?lat=${coordinates.lat}&lng=${coordinates.lng}`
        );
      }

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Search failed');
      }

      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Batch address lookup
  const handleBatchSearch = async () => {
    const addresses = batchAddresses
      .split('\n')
      .map(a => a.trim())
      .filter(a => a.length > 0);

    if (addresses.length === 0) {
      setError('Please enter at least one address');
      return;
    }

    if (addresses.length > 50) {
      setError('Maximum 50 addresses allowed');
      return;
    }

    setLoading(true);
    setError(null);
    setBatchResults(null);

    try {
      const response = await fetch(`${API_BASE}/parcel/batch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ addresses })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Batch search failed');
      }

      setBatchResults(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Download results as JSON
  const downloadResults = useCallback(() => {
    const dataToDownload = batchResults || result;
    const blob = new Blob([JSON.stringify(dataToDownload, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `parcel-data-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [result, batchResults]);

  // Format currency
  const formatCurrency = (value) => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(value);
  };

  // Render parcel details
  const renderParcelDetails = (parcel) => {
    if (!parcel) return null;

    return (
      <div className="parcel-details">
        <div className="detail-grid">
          {/* Property Info */}
          <div className="detail-card">
            <div className="card-header">
              <Home size={20} />
              <h3>Property Information</h3>
            </div>
            <div className="detail-rows">
              <div className="detail-row">
                <span className="label">Parcel ID:</span>
                <span className="value">{parcel.PARCEL_ID || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Owner:</span>
                <span className="value">{parcel.OWNER_NAME || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Site Address:</span>
                <span className="value">{parcel.SITE_ADDR || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Mailing Address:</span>
                <span className="value">{parcel.MAIL_ADDR || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Legal Description:</span>
                <span className="value legal-desc">{parcel.LEGAL_DESC || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Financial Info */}
          <div className="detail-card">
            <div className="card-header">
              <DollarSign size={20} />
              <h3>Financial Details</h3>
            </div>
            <div className="detail-rows">
              <div className="detail-row">
                <span className="label">Assessed Value:</span>
                <span className="value highlight">{formatCurrency(parcel.ASSESSED_VAL)}</span>
              </div>
              <div className="detail-row">
                <span className="label">Tax Year:</span>
                <span className="value">{parcel.TAX_YEAR || 'N/A'}</span>
              </div>
              {parcel.derivedProperties && (
                <div className="detail-row">
                  <span className="label">Value per Acre:</span>
                  <span className="value">
                    {formatCurrency(parcel.derivedProperties.assessedValuePerAcre)}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Land Info */}
          <div className="detail-card">
            <div className="card-header">
              <Maximize2 size={20} />
              <h3>Land Details</h3>
            </div>
            <div className="detail-rows">
              <div className="detail-row">
                <span className="label">Acres:</span>
                <span className="value">{parcel.ACRES || 'N/A'}</span>
              </div>
              <div className="detail-row">
                <span className="label">Zoning:</span>
                <span className="value">{parcel.ZONING || 'N/A'}</span>
              </div>
              {parcel.location && (
                <>
                  <div className="detail-row">
                    <span className="label">Latitude:</span>
                    <span className="value">{parcel.location.latitude?.toFixed(6)}</span>
                  </div>
                  <div className="detail-row">
                    <span className="label">Longitude:</span>
                    <span className="value">{parcel.location.longitude?.toFixed(6)}</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Metadata */}
          {parcel.metadata && (
            <div className="detail-card">
              <div className="card-header">
                <TrendingUp size={20} />
                <h3>Metadata</h3>
              </div>
              <div className="detail-rows">
                <div className="detail-row">
                  <span className="label">Query Time:</span>
                  <span className="value">
                    {new Date(parcel.metadata.queryTimestamp).toLocaleString()}
                  </span>
                </div>
                <div className="detail-row">
                  <span className="label">Source:</span>
                  <span className="value">{parcel.metadata.source}</span>
                </div>
                <div className="detail-row">
                  <span className="label">Coordinate System:</span>
                  <span className="value">{parcel.metadata.coordinateSystem}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-content">
          <div className="logo">
            <MapPin size={32} />
            <h1>Parcel Finder</h1>
            <span className="beta-badge">BETA</span>
          </div>
          <div className="header-actions">
            <button
              className={`mode-toggle ${showBatchMode ? 'active' : ''}`}
              onClick={() => setShowBatchMode(!showBatchMode)}
            >
              <List size={18} />
              {showBatchMode ? 'Single Mode' : 'Batch Mode'}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        <div className="container">
          {/* Search Panel */}
          <div className="search-panel">
            {!showBatchMode ? (
              <>
                {/* Search Mode Toggle */}
                <div className="search-mode-toggle">
                  <button
                    className={searchMode === 'address' ? 'active' : ''}
                    onClick={() => setSearchMode('address')}
                  >
                    <Home size={16} />
                    Address
                  </button>
                  <button
                    className={searchMode === 'coordinates' ? 'active' : ''}
                    onClick={() => setSearchMode('coordinates')}
                  >
                    <MapIcon size={16} />
                    Coordinates
                  </button>
                </div>

                {/* Single Search Input */}
                {searchMode === 'address' ? (
                  <div className="search-input-group">
                    <input
                      type="text"
                      placeholder="Enter address (e.g., 1210 Eaton Ave, Allentown, PA)"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                      className="search-input"
                    />
                    <button
                      onClick={handleSearch}
                      disabled={loading}
                      className="search-button"
                    >
                      {loading ? <Loader className="spin" size={20} /> : <Search size={20} />}
                      Search
                    </button>
                  </div>
                ) : (
                  <div className="coordinates-input">
                    <input
                      type="number"
                      step="any"
                      placeholder="Latitude"
                      value={coordinates.lat}
                      onChange={(e) => setCoordinates({ ...coordinates, lat: e.target.value })}
                      className="coord-input"
                    />
                    <input
                      type="number"
                      step="any"
                      placeholder="Longitude"
                      value={coordinates.lng}
                      onChange={(e) => setCoordinates({ ...coordinates, lng: e.target.value })}
                      className="coord-input"
                    />
                    <button
                      onClick={handleSearch}
                      disabled={loading}
                      className="search-button"
                    >
                      {loading ? <Loader className="spin" size={20} /> : <Search size={20} />}
                      Search
                    </button>
                  </div>
                )}
              </>
            ) : (
              <>
                {/* Batch Search Input */}
                <div className="batch-input-group">
                  <label>Enter addresses (one per line, max 50):</label>
                  <textarea
                    placeholder="1210 Eaton Ave, Allentown, PA&#10;123 Main St, Allentown, PA&#10;..."
                    value={batchAddresses}
                    onChange={(e) => setBatchAddresses(e.target.value)}
                    className="batch-textarea"
                    rows={8}
                  />
                  <button
                    onClick={handleBatchSearch}
                    disabled={loading}
                    className="search-button"
                  >
                    {loading ? <Loader className="spin" size={20} /> : <Search size={20} />}
                    Search All
                  </button>
                </div>
              </>
            )}
          </div>

          {/* Error Message */}
          {error && (
            <div className="alert alert-error">
              <AlertCircle size={20} />
              <span>{error}</span>
            </div>
          )}

          {/* Results Panel */}
          {!showBatchMode && result && result.data && (
            <div className="results-panel">
              <div className="results-header">
                <div className="results-title">
                  <CheckCircle size={24} className="success-icon" />
                  <h2>Parcel Found</h2>
                </div>
                <div className="results-actions">
                  {result.metadata && (
                    <span className="query-time">
                      Query time: {result.metadata.queryDuration?.toFixed(2)}ms
                    </span>
                  )}
                  <button onClick={downloadResults} className="download-button">
                    <Download size={18} />
                    Download JSON
                  </button>
                </div>
              </div>

              {renderParcelDetails(result.data)}
            </div>
          )}

          {/* Batch Results */}
          {showBatchMode && batchResults && (
            <div className="batch-results-panel">
              <div className="batch-summary">
                <h2>Batch Results</h2>
                <div className="summary-stats">
                  <div className="stat">
                    <span className="stat-label">Total:</span>
                    <span className="stat-value">{batchResults.summary.total}</span>
                  </div>
                  <div className="stat success">
                    <span className="stat-label">Success:</span>
                    <span className="stat-value">{batchResults.summary.succeeded}</span>
                  </div>
                  <div className="stat error">
                    <span className="stat-label">Failed:</span>
                    <span className="stat-value">{batchResults.summary.failed}</span>
                  </div>
                  <div className="stat">
                    <span className="stat-label">Duration:</span>
                    <span className="stat-value">{batchResults.summary.duration?.toFixed(2)}ms</span>
                  </div>
                </div>
                <button onClick={downloadResults} className="download-button">
                  <Download size={18} />
                  Download All Results
                </button>
              </div>

              <div className="batch-results-list">
                {batchResults.results.map((result, index) => (
                  <div
                    key={index}
                    className={`batch-result-item ${result.status === 'fulfilled' && result.data ? 'success' : 'failed'}`}
                  >
                    <div className="batch-result-header">
                      <span className="batch-address">{result.address}</span>
                      {result.status === 'fulfilled' && result.data ? (
                        <CheckCircle size={20} className="status-icon success" />
                      ) : (
                        <AlertCircle size={20} className="status-icon error" />
                      )}
                    </div>
                    {result.status === 'fulfilled' && result.data ? (
                      <div className="batch-result-summary">
                        <span>Owner: {result.data.OWNER_NAME || 'N/A'}</span>
                        <span>Parcel ID: {result.data.PARCEL_ID || 'N/A'}</span>
                        <span>Value: {formatCurrency(result.data.ASSESSED_VAL)}</span>
                      </div>
                    ) : (
                      <div className="batch-result-error">
                        {result.error || 'No parcel found'}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Empty State */}
          {!loading && !result && !batchResults && !error && (
            <div className="empty-state">
              <MapPin size={64} className="empty-icon" />
              <h3>Ready to Search</h3>
              <p>
                {showBatchMode
                  ? 'Enter multiple addresses to search for parcels in bulk'
                  : 'Enter an address or coordinates to find parcel information'}
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="footer">
        <p>Parcel Finder Beta v1.0.0 | Data from Lehigh County Parcel Viewer</p>
      </footer>
    </div>
  );
}

export default App;
