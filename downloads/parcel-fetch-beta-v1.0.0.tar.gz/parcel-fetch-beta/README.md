# 🗺️ Parcel Finder - Beta

A modern web application for finding parcel information by address or coordinates with geocoding support.

![Version](https://img.shields.io/badge/version-1.0.0--beta-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

## ✨ Features

- **Address Lookup**: Find parcels by entering a street address
- **Coordinate Search**: Look up parcels using latitude/longitude
- **Batch Processing**: Process multiple addresses at once (up to 50)
- **Real-time Geocoding**: Automatic address-to-coordinate conversion
- **Comprehensive Data**: Property info, financial details, land specifications
- **Performance Tracking**: Built-in performance monitoring and logging
- **Modern UI**: Clean, responsive interface built with React
- **RESTful API**: Well-documented API endpoints

## 🏗️ Architecture

```
parcel-fetch-beta/
├── client/                 # React frontend
│   ├── src/
│   │   ├── App.jsx        # Main application component
│   │   ├── App.css        # Styling
│   │   └── main.jsx       # Entry point
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── server/                 # Express backend
│   ├── src/
│   │   ├── advanced-logger.js
│   │   ├── geocoding.js
│   │   └── parcel-fetcher.js
│   ├── config/
│   │   └── parcel-config.json
│   ├── index.js           # API server
│   └── package.json
└── README.md
```

## 🚀 Quick Start

### Prerequisites

- Node.js 14+ 
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd parcel-fetch-beta
   ```

2. **Install server dependencies**
   ```bash
   cd server
   npm install
   cp .env.example .env
   ```

3. **Install client dependencies**
   ```bash
   cd ../client
   npm install
   ```

### Running the Application

#### Option 1: Run Both (Recommended)

**Terminal 1 - Start the backend:**
```bash
cd server
npm run dev
```
Server will run on `http://localhost:4000`

**Terminal 2 - Start the frontend:**
```bash
cd client
npm run dev
```
Client will run on `http://localhost:3000`

#### Option 2: Production Build

**Build the client:**
```bash
cd client
npm run build
```

**Serve everything from the backend:**
```bash
cd server
npm start
```

### Access the Application

Open your browser and navigate to:
- **Frontend**: `http://localhost:3000`
- **API**: `http://localhost:4000/api`
- **Health Check**: `http://localhost:4000/api/health`

## 📖 API Documentation

### Endpoints

#### Health Check
```http
GET /api/health
```

**Response:**
```json
{
  "status": "ok",
  "uptime": 12345.67,
  "version": "1.0.0-beta",
  "diagnostics": { ... }
}
```

#### Single Address Lookup
```http
POST /api/parcel/lookup
Content-Type: application/json

{
  "address": "1210 Eaton Ave, Allentown, PA",
  "language": "en"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "PARCEL_ID": "123456",
    "OWNER_NAME": "John Doe",
    "SITE_ADDR": "1210 Eaton Ave",
    "ASSESSED_VAL": 250000,
    "ACRES": 0.25,
    "location": {
      "latitude": 40.1234,
      "longitude": -75.5678
    },
    ...
  },
  "metadata": {
    "queryDuration": 234.56,
    "timestamp": "2024-02-14T10:30:00Z"
  }
}
```

#### Coordinate Lookup
```http
GET /api/parcel/coordinates?lat=40.1234&lng=-75.5678
```

#### Batch Lookup
```http
POST /api/parcel/batch
Content-Type: application/json

{
  "addresses": [
    "1210 Eaton Ave, Allentown, PA",
    "123 Main St, Allentown, PA"
  ]
}
```

**Response:**
```json
{
  "success": true,
  "results": [ ... ],
  "summary": {
    "total": 2,
    "succeeded": 2,
    "failed": 0,
    "duration": 456.78
  }
}
```

#### System Statistics
```http
GET /api/stats
```

## ⚙️ Configuration

### Server Configuration

Edit `server/config/parcel-config.json`:

```json
{
  "LAYER_URL": "your-arcgis-layer-url",
  "LOG_LEVEL": "info",
  "DEFAULT_FIELDS": [ ... ],
  "PERFORMANCE_THRESHOLDS": {
    "slowQueryMs": 500,
    "criticalQueryMs": 2000
  }
}
```

### Environment Variables

Edit `server/.env`:

```env
PORT=4000
NODE_ENV=development
LOG_LEVEL=info
ALLOWED_ORIGINS=http://localhost:3000
```

## 🔧 Development

### Running Tests
```bash
# Server tests
cd server
npm test

# Client tests
cd client
npm test
```

### Linting
```bash
# Server
cd server
npm run lint

# Client
cd client
npm run lint
```

### Building for Production
```bash
# Build client
cd client
npm run build

# The built files will be in client/dist/
```

## 📊 Logging

Logs are stored in `server/logs/`:
- `combined.log` - All logs
- `error.log` - Error logs only

Log levels: `error`, `warn`, `info`, `debug`

## 🐛 Troubleshooting

### Common Issues

**Port already in use:**
```bash
# Change PORT in server/.env
PORT=5000
```

**CORS errors:**
```bash
# Update ALLOWED_ORIGINS in server/.env
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173
```

**Geocoding failures:**
- Check internet connection
- Verify address format
- Check geocoding API limits

**No parcel found:**
- Try nearby coordinates
- Check if address is in the coverage area
- Verify ArcGIS layer URL

## 📝 License

MIT License - see LICENSE file for details

## 🙏 Acknowledgments

- Data from Lehigh County Parcel Viewer
- Geocoding by Google Maps API
- Built with React, Express, and Node.js

## 🚀 Roadmap

- [ ] Add map visualization
- [ ] Export to PDF/CSV
- [ ] User authentication
- [ ] Save favorite searches
- [ ] Advanced filtering
- [ ] Mobile app

## 📧 Support

For issues and questions, please open an issue on GitHub.

---

**Made with ❤️ for better property data access**
