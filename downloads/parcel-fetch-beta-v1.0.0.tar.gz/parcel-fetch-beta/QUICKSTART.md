# 🚀 Quick Start Guide

Get up and running with Parcel Finder in 5 minutes!

## Prerequisites

- **Node.js 14+** - [Download](https://nodejs.org/)
- **npm** (comes with Node.js)
- **Git** (optional)

## Installation

### Option 1: Automated Setup (Recommended)

**Linux/Mac:**
```bash
./setup.sh
```

**Windows:**
```cmd
setup.bat
```

### Option 2: Manual Setup

**1. Install server dependencies:**
```bash
cd server
npm install
cp .env.example .env
```

**2. Install client dependencies:**
```bash
cd ../client
npm install
```

**3. Create directories:**
```bash
mkdir -p server/logs server/output
```

## Running the Application

### Development Mode

Open two terminals:

**Terminal 1 - Backend:**
```bash
cd server
npm run dev
```
✅ Server running at `http://localhost:4000`

**Terminal 2 - Frontend:**
```bash
cd client
npm run dev
```
✅ App running at `http://localhost:3000`

### Docker (All-in-One)

```bash
docker-compose up
```

Access at `http://localhost:3000`

## Using the Application

### 1. Single Address Search

1. Make sure "Address" mode is selected
2. Enter an address: `1210 Eaton Ave, Allentown, PA`
3. Click "Search"
4. View parcel details

### 2. Coordinate Search

1. Click "Coordinates" mode
2. Enter latitude: `40.123456`
3. Enter longitude: `-75.654321`
4. Click "Search"

### 3. Batch Processing

1. Click "Batch Mode" button
2. Enter addresses (one per line):
   ```
   1210 Eaton Ave, Allentown, PA
   123 Main St, Allentown, PA
   456 Oak Rd, Allentown, PA
   ```
3. Click "Search All"
4. View results for all addresses

### 4. Download Results

Click the "Download JSON" button to save results to a file.

## API Usage

### Health Check

```bash
curl http://localhost:4000/api/health
```

### Single Lookup

```bash
curl -X POST http://localhost:4000/api/parcel/lookup \
  -H "Content-Type: application/json" \
  -d '{"address":"1210 Eaton Ave, Allentown, PA"}'
```

### Batch Lookup

```bash
curl -X POST http://localhost:4000/api/parcel/batch \
  -H "Content-Type: application/json" \
  -d '{"addresses":["1210 Eaton Ave, Allentown, PA","123 Main St, Allentown, PA"]}'
```

See [API.md](API.md) for complete documentation.

## Configuration

### Server Configuration

Edit `server/.env`:
```env
PORT=4000
NODE_ENV=development
LOG_LEVEL=info
```

Edit `server/config/parcel-config.json`:
```json
{
  "LAYER_URL": "your-arcgis-url",
  "LOG_LEVEL": "info",
  "PERFORMANCE_THRESHOLDS": {
    "slowQueryMs": 500,
    "criticalQueryMs": 2000
  }
}
```

## Troubleshooting

### Port Already in Use

**Backend:**
Change `PORT` in `server/.env`

**Frontend:**
Vite will automatically try the next available port

### CORS Errors

Update `ALLOWED_ORIGINS` in `server/.env`:
```env
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173
```

### No Parcel Found

- Verify the address is in Lehigh County, PA
- Try nearby coordinates
- Check the ArcGIS layer URL in config

### Geocoding Failures

- Check internet connection
- Verify Google Maps API is accessible
- Try different address formats

## Next Steps

1. ✅ Read the [README.md](README.md) for detailed information
2. ✅ Check [API.md](API.md) for API documentation
3. ✅ Review [CHANGELOG.md](CHANGELOG.md) for updates
4. ✅ Customize configuration for your needs

## Getting Help

- 📖 [Full Documentation](README.md)
- 🐛 [Report Issues](https://github.com/your-repo/issues)
- 💬 [Discussions](https://github.com/your-repo/discussions)

## Common Use Cases

### Real Estate Research
Search properties by address to get ownership, assessed value, and zoning information.

### Property Development
Batch process multiple addresses to analyze areas for development opportunities.

### Tax Assessment
Look up property tax information and assessed values.

### GIS Analysis
Export coordinate data for use in GIS software.

---

**Ready to explore? Start searching for parcels! 🗺️**
