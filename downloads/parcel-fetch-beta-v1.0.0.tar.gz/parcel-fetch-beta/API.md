# API Documentation

## Base URL

```
http://localhost:4000/api
```

## Authentication

Currently, the API does not require authentication. This will be added in future versions.

## Rate Limiting

- **Limit**: 100 requests per 15 minutes per IP
- **Headers**: 
  - `X-RateLimit-Limit`: Request limit
  - `X-RateLimit-Remaining`: Remaining requests
  - `X-RateLimit-Reset`: Reset timestamp

## Endpoints

### 1. Health Check

Get API health status and system information.

**Endpoint**: `GET /api/health`

**Response** (200 OK):
```json
{
  "status": "ok",
  "uptime": 12345.67,
  "timestamp": "2024-02-14T10:30:00.000Z",
  "version": "1.0.0-beta",
  "diagnostics": {
    "systemInfo": {
      "platform": "linux",
      "arch": "x64",
      "cpus": 8,
      "totalMemory": "16.00 GB",
      "freeMemory": "8.00 GB",
      "nodeVersion": "v18.0.0"
    }
  }
}
```

---

### 2. Single Address Lookup

Geocode an address and find the corresponding parcel.

**Endpoint**: `POST /api/parcel/lookup`

**Request Body**:
```json
{
  "address": "1210 Eaton Ave, Allentown, PA",
  "language": "en"  // Optional: en, es, fr, de
}
```

**Validation**:
- `address`: Required, 5-200 characters
- `language`: Optional, must be one of: en, es, fr, de

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "PARCEL_ID": "540532405713",
    "OWNER_NAME": "SMITH JOHN & JANE",
    "MAIL_ADDR": "1210 EATON AVE ALLENTOWN PA 18103",
    "SITE_ADDR": "1210 EATON AVE",
    "LEGAL_DESC": "LOT 123 PLAN ABC",
    "ACRES": 0.25,
    "ZONING": "R-2",
    "ASSESSED_VAL": 250000,
    "TAX_YEAR": 2024,
    "geometry": { ... },
    "location": {
      "latitude": 40.123456,
      "longitude": -75.654321,
      "precision": "high"
    },
    "metadata": {
      "queryTimestamp": "2024-02-14T10:30:00.000Z",
      "source": "Lehigh County Parcel Viewer",
      "coordinateSystem": "WGS84",
      "layerUrl": "https://..."
    },
    "derivedProperties": {
      "assessedValuePerAcre": 1000000,
      "propertyAge": 0,
      "hasMultipleOwners": true
    },
    "geocoding": {
      "input_address": "1210 Eaton Ave, Allentown, PA",
      "formatted_address": "1210 Eaton Ave, Allentown, PA 18103, USA",
      "place_id": "ChIJ..."
    }
  },
  "metadata": {
    "queryDuration": 234.56,
    "timestamp": "2024-02-14T10:30:00.000Z"
  }
}
```

**Error Responses**:

*400 Bad Request*:
```json
{
  "errors": [
    {
      "msg": "Invalid value",
      "param": "address",
      "location": "body"
    }
  ]
}
```

*404 Not Found*:
```json
{
  "error": "Parcel not found",
  "message": "No parcel data found for address: ..."
}
```

*500 Internal Server Error*:
```json
{
  "error": "Lookup failed",
  "message": "Geocoding failed for address..."
}
```

---

### 3. Coordinate Lookup

Find parcel by latitude and longitude.

**Endpoint**: `GET /api/parcel/coordinates`

**Query Parameters**:
- `lat` (required): Latitude (-90 to 90)
- `lng` (required): Longitude (-180 to 180)

**Example**:
```
GET /api/parcel/coordinates?lat=40.123456&lng=-75.654321
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": { ... },  // Same as address lookup
  "metadata": {
    "queryDuration": 123.45,
    "timestamp": "2024-02-14T10:30:00.000Z"
  }
}
```

**Error Responses**:

*400 Bad Request*:
```json
{
  "errors": [
    {
      "msg": "Invalid value",
      "param": "lat",
      "location": "query"
    }
  ]
}
```

---

### 4. Batch Lookup

Process multiple addresses in a single request.

**Endpoint**: `POST /api/parcel/batch`

**Request Body**:
```json
{
  "addresses": [
    "1210 Eaton Ave, Allentown, PA",
    "123 Main St, Allentown, PA",
    "456 Oak Rd, Allentown, PA"
  ]
}
```

**Validation**:
- `addresses`: Required array, 1-50 items
- Each address: Non-empty string

**Response** (200 OK):
```json
{
  "success": true,
  "results": [
    {
      "address": "1210 Eaton Ave, Allentown, PA",
      "status": "fulfilled",
      "data": { ... },  // Parcel data
      "error": null
    },
    {
      "address": "123 Main St, Allentown, PA",
      "status": "rejected",
      "data": null,
      "error": "No parcel found"
    }
  ],
  "summary": {
    "total": 3,
    "succeeded": 2,
    "failed": 1,
    "duration": 456.78
  }
}
```

**Error Responses**:

*400 Bad Request*:
```json
{
  "errors": [
    {
      "msg": "Invalid value",
      "param": "addresses",
      "location": "body"
    }
  ]
}
```

*429 Too Many Requests*:
```json
{
  "error": "Too many requests from this IP, please try again later."
}
```

---

### 5. System Statistics

Get system statistics and diagnostics.

**Endpoint**: `GET /api/stats`

**Response** (200 OK):
```json
{
  "system": {
    "platform": "linux",
    "arch": "x64",
    "cpus": 8,
    "totalMemory": "16.00 GB",
    "freeMemory": "8.00 GB",
    "nodeVersion": "v18.0.0"
  },
  "logger": {
    "logLevel": "info",
    "remoteLogging": false
  },
  "service": {
    "uptime": 12345.67,
    "memoryUsage": {
      "rss": 123456789,
      "heapTotal": 98765432,
      "heapUsed": 87654321,
      "external": 1234567
    },
    "version": "1.0.0-beta"
  }
}
```

---

## Error Handling

All errors follow this format:

```json
{
  "error": "Error type",
  "message": "Human-readable error message"
}
```

### Common HTTP Status Codes

- `200 OK`: Successful request
- `400 Bad Request`: Invalid input
- `404 Not Found`: Resource not found
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: Server error
- `503 Service Unavailable`: Service temporarily unavailable

---

## Performance Notes

- **Single lookup**: ~200-500ms average
- **Batch lookup**: ~100-200ms per address
- **Timeout**: 30 seconds per request
- **Slow query threshold**: 500ms
- **Critical query threshold**: 2000ms

Queries exceeding thresholds are logged for monitoring.

---

## Best Practices

1. **Batch requests** when possible to reduce overhead
2. **Cache results** on the client side to minimize API calls
3. **Handle errors gracefully** - check for both `404` and `500` responses
4. **Validate coordinates** before sending (lat: -90 to 90, lng: -180 to 180)
5. **Format addresses properly** - include city and state for better geocoding
6. **Monitor rate limits** via response headers

---

## Examples

### cURL Examples

**Health check**:
```bash
curl http://localhost:4000/api/health
```

**Address lookup**:
```bash
curl -X POST http://localhost:4000/api/parcel/lookup \
  -H "Content-Type: application/json" \
  -d '{"address":"1210 Eaton Ave, Allentown, PA"}'
```

**Coordinate lookup**:
```bash
curl "http://localhost:4000/api/parcel/coordinates?lat=40.123456&lng=-75.654321"
```

**Batch lookup**:
```bash
curl -X POST http://localhost:4000/api/parcel/batch \
  -H "Content-Type: application/json" \
  -d '{"addresses":["1210 Eaton Ave, Allentown, PA","123 Main St, Allentown, PA"]}'
```

### JavaScript Examples

```javascript
// Single lookup
const response = await fetch('http://localhost:4000/api/parcel/lookup', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ address: '1210 Eaton Ave, Allentown, PA' })
});
const data = await response.json();

// Coordinate lookup
const response = await fetch(
  'http://localhost:4000/api/parcel/coordinates?lat=40.123456&lng=-75.654321'
);
const data = await response.json();

// Batch lookup
const response = await fetch('http://localhost:4000/api/parcel/batch', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    addresses: [
      '1210 Eaton Ave, Allentown, PA',
      '123 Main St, Allentown, PA'
    ]
  })
});
const data = await response.json();
```

---

## Changelog

See [CHANGELOG.md](../CHANGELOG.md) for version history and updates.
