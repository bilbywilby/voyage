# 🚢 Deployment Guide

Complete guide for deploying Parcel Finder to production.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Local Production Build](#local-production-build)
3. [Docker Deployment](#docker-deployment)
4. [Cloud Deployment](#cloud-deployment)
5. [Environment Configuration](#environment-configuration)
6. [Security Best Practices](#security-best-practices)
7. [Monitoring & Logging](#monitoring--logging)
8. [Scaling](#scaling)

---

## Prerequisites

- **Node.js 14+**
- **Docker** (optional, for containerized deployment)
- **Domain name** (for production)
- **SSL certificate** (Let's Encrypt recommended)
- **Server** with at least 1GB RAM, 1 CPU

---

## Local Production Build

### Build the Client

```bash
cd client
npm run build
```

The built files will be in `client/dist/`

### Run Server in Production Mode

```bash
cd server
NODE_ENV=production npm start
```

### Serve Everything from Node

Modify `server/index.js` to serve static files:

```javascript
// Add after other middleware
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/dist/index.html'));
  });
}
```

---

## Docker Deployment

### Using Docker Compose (Recommended)

**1. Build and start:**
```bash
docker-compose up -d
```

**2. View logs:**
```bash
docker-compose logs -f
```

**3. Stop:**
```bash
docker-compose down
```

### Using Docker Directly

**Build images:**
```bash
# Backend
cd server
docker build -t parcel-fetch-api .

# Frontend
cd ../client
docker build -t parcel-fetch-web .
```

**Run containers:**
```bash
# Backend
docker run -d \
  --name parcel-api \
  -p 4000:4000 \
  -v $(pwd)/server/logs:/app/logs \
  parcel-fetch-api

# Frontend
docker run -d \
  --name parcel-web \
  -p 3000:80 \
  --link parcel-api \
  parcel-fetch-web
```

---

## Cloud Deployment

### AWS (EC2)

**1. Launch EC2 Instance:**
- AMI: Ubuntu 22.04
- Instance type: t2.micro or larger
- Security groups: Allow ports 22, 80, 443

**2. Install dependencies:**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install Docker
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
```

**3. Clone and deploy:**
```bash
git clone <your-repo>
cd parcel-fetch-beta
./setup.sh
docker-compose up -d
```

**4. Setup Nginx reverse proxy:**
```bash
sudo apt install nginx

# Configure Nginx
sudo nano /etc/nginx/sites-available/parcel-finder
```

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /api {
        proxy_pass http://localhost:4000;
        proxy_http_version 1.1;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/parcel-finder /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

**5. SSL with Let's Encrypt:**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### DigitalOcean

**1. Create Droplet:**
- Choose Ubuntu 22.04
- Select size (1GB RAM minimum)
- Add SSH key

**2. Follow AWS steps 2-5**

### Heroku

**Create `Procfile` in root:**
```
web: cd server && npm start
```

**Deploy:**
```bash
heroku login
heroku create parcel-finder
git push heroku main
```

### Vercel (Frontend Only)

```bash
cd client
npm i -g vercel
vercel
```

---

## Environment Configuration

### Production Environment Variables

**server/.env:**
```env
# Server
PORT=4000
NODE_ENV=production

# Logging
LOG_LEVEL=info

# Security
ALLOWED_ORIGINS=https://your-domain.com

# ArcGIS (if needed)
ARCGIS_API_KEY=your-key-here
```

### Security Considerations

1. **Never commit `.env` files**
2. **Use environment-specific configs**
3. **Rotate API keys regularly**
4. **Enable HTTPS only in production**

---

## Security Best Practices

### 1. Update Dependencies

```bash
npm audit
npm audit fix
```

### 2. Rate Limiting

Already implemented in `server/index.js`:
```javascript
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
});
```

Adjust for production needs.

### 3. Helmet Configuration

Add custom CSP:
```javascript
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));
```

### 4. CORS Configuration

```javascript
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS.split(','),
  credentials: true
}));
```

### 5. Input Validation

Already implemented using `express-validator`.

### 6. Logging

- Use structured logging
- Mask sensitive data
- Implement log rotation
- Send logs to centralized service

---

## Monitoring & Logging

### Application Monitoring

**PM2 (Process Manager):**
```bash
npm install -g pm2

# Start application
cd server
pm2 start index.js --name parcel-api

# Monitor
pm2 monit

# Logs
pm2 logs parcel-api

# Auto-restart on server reboot
pm2 startup
pm2 save
```

### Log Management

**Using Winston (already configured):**
- Logs stored in `server/logs/`
- Automatic log rotation
- Error logs separated

**Centralized Logging:**
```bash
# Install log shipper
npm install winston-cloudwatch

# Configure in advanced-logger.js
```

### Health Checks

**Endpoint:** `GET /api/health`

**Monitor with cron:**
```bash
*/5 * * * * curl -f http://localhost:4000/api/health || echo "API down" | mail -s "Alert" admin@example.com
```

### Performance Monitoring

**New Relic:**
```bash
npm install newrelic
# Add to index.js
require('newrelic');
```

**Datadog:**
```bash
npm install dd-trace
# Add to index.js
require('dd-trace').init();
```

---

## Scaling

### Horizontal Scaling

**Using PM2 Cluster Mode:**
```bash
pm2 start index.js -i max --name parcel-api
```

**Load Balancer (Nginx):**
```nginx
upstream api_backend {
    server localhost:4000;
    server localhost:4001;
    server localhost:4002;
}

server {
    location /api {
        proxy_pass http://api_backend;
    }
}
```

### Vertical Scaling

- Increase server resources (RAM, CPU)
- Optimize database queries
- Add caching layer (Redis)

### Caching Strategy

**Add Redis:**
```bash
npm install redis
```

**Implement caching:**
```javascript
const redis = require('redis');
const client = redis.createClient();

// Cache geocoding results
async function geocodeWithCache(address) {
  const cached = await client.get(`geo:${address}`);
  if (cached) return JSON.parse(cached);
  
  const result = await geocode(address);
  await client.setEx(`geo:${address}`, 3600, JSON.stringify(result));
  return result;
}
```

### Database Optimization

For future versions with persistent storage:
- Index frequently queried fields
- Use connection pooling
- Implement query caching
- Consider read replicas

---

## Backup & Recovery

### Backup Logs

```bash
# Daily backup
0 2 * * * tar -czf /backups/logs-$(date +\%Y\%m\%d).tar.gz /app/logs
```

### Backup Configuration

```bash
# Weekly backup
0 0 * * 0 tar -czf /backups/config-$(date +\%Y\%m\%d).tar.gz /app/config
```

---

## Rollback Strategy

### Using Git Tags

```bash
# Tag current version
git tag -a v1.0.0 -m "Production release"
git push origin v1.0.0

# Rollback if needed
git checkout v1.0.0
docker-compose up -d --build
```

### Blue-Green Deployment

1. Deploy new version to separate environment
2. Test thoroughly
3. Switch traffic
4. Keep old version running for quick rollback

---

## Performance Optimization

### 1. Enable Gzip Compression

```javascript
const compression = require('compression');
app.use(compression());
```

### 2. Optimize Static Assets

- Minify JS/CSS (done by Vite)
- Use CDN for static assets
- Implement browser caching

### 3. Database Query Optimization

- Use connection pooling
- Index frequently queried fields
- Implement pagination

### 4. API Response Optimization

- Implement response caching
- Use compression
- Minimize payload size

---

## Troubleshooting Production Issues

### High CPU Usage

```bash
# Check process
top -c
pm2 monit

# Analyze Node.js heap
node --inspect index.js
```

### Memory Leaks

```bash
# Monitor memory
pm2 monit

# Heap snapshot
node --heap-prof index.js
```

### Slow Queries

Check `server/logs/combined.log` for queries > 500ms

---

## Maintenance Checklist

### Daily
- [ ] Check health endpoint
- [ ] Review error logs
- [ ] Monitor resource usage

### Weekly
- [ ] Backup configurations
- [ ] Review slow queries
- [ ] Update dependencies (test first)

### Monthly
- [ ] Security audit
- [ ] Performance review
- [ ] Capacity planning

---

## Support

For deployment issues:
1. Check logs: `docker-compose logs`
2. Verify configuration
3. Review this guide
4. Open issue on GitHub

---

**Happy Deploying! 🚀**
