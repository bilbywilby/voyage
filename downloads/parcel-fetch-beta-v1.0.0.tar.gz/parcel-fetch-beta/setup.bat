@echo off
REM Parcel Fetch Beta - Setup Script for Windows

echo.
echo 🗺️  Parcel Finder Beta - Setup Script
echo ======================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ Node.js is not installed. Please install Node.js 14+ first.
    exit /b 1
)

echo ✅ Node.js detected
echo.

REM Install server dependencies
echo 📦 Installing server dependencies...
cd server
if not exist ".env" (
    echo Creating .env file from example...
    copy .env.example .env
)
call npm install
cd ..

echo ✅ Server dependencies installed
echo.

REM Install client dependencies
echo 📦 Installing client dependencies...
cd client
call npm install
cd ..

echo ✅ Client dependencies installed
echo.

REM Create necessary directories
echo 📁 Creating necessary directories...
if not exist "server\logs" mkdir server\logs
if not exist "server\output" mkdir server\output

echo ✅ Directories created
echo.

echo ✨ Setup complete!
echo.
echo 🚀 To start the application:
echo.
echo   Terminal 1 (Backend):
echo     cd server
echo     npm run dev
echo.
echo   Terminal 2 (Frontend):
echo     cd client
echo     npm run dev
echo.
echo   Then open: http://localhost:3000
echo.
echo 📖 For more information, see README.md
echo.
echo 🐳 Alternatively, use Docker:
echo     docker-compose up
echo.

pause
